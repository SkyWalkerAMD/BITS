// SPDX-License-Identifier: GPL-2.0-or-later

/*
 * Copyright (C) 2019 Joe Korty <joe.korty@concurrent-rt.com>
 */

/*
 * Have a tracer do a bunch of PTRACE_SINGLESTEPs against
 * a tracee as fast as possible.  Create several of these
 * tracer/tracee pairs and see if they can be made to
 * interfere with each other.
 *
 * Usage:
 *   ssdd nforks niters
 * Where:
 *   nforks - number of tracer/tracee pairs to fork off.
 *            default 10.
 *   niters - number of PTRACE_SINGLESTEP iterations to
 *            do before declaring success, for each tracer/
 *            tracee pair set up.  Default 10,000.
 *
 * The tracer waits on each PTRACE_SINGLESTEP with a waitpid(2)
 * and checks that waitpid's return values for correctness.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ptrace.h>

#include "rt-utils.h"

/* do_wait return values */
#define STATE_EXITED	1
#define STATE_STOPPED	2
#define STATE_SIGNALED	3
#define STATE_UNKNOWN	4
#define STATE_ECHILD	5
#define STATE_EXITED_TSIG	6	/* exited with termination signal */
#define STATE_EXITED_ERRSTAT	7	/* exited with non-zero status */

static char *state_name[] = {
	[STATE_EXITED] = "STATE_EXITED",
	[STATE_STOPPED] = "STATE_STOPPED",
	[STATE_SIGNALED] = "STATE_SIGNALED",
	[STATE_UNKNOWN] = "STATE_UNKNOWN",
	[STATE_ECHILD] = "STATE_ECHILD",
	[STATE_EXITED_TSIG] = "STATE_EXITED_TSIG",
	[STATE_EXITED_ERRSTAT] = "STATE_EXITED_ERRSTAT"
};

static const char *get_state_name(int state)
{
	if (state < STATE_EXITED || state > STATE_EXITED_ERRSTAT)
		return "?";
	return state_name[state];
}

static int quiet;
static char jsonfile[MAX_PATH];

volatile int got_sigchld;

enum option_value { OPT_NFORKS=1, OPT_NITERS, OPT_HELP, OPT_JSON, OPT_QUIET };

static void usage(int error)
{
	printf("ssdd V %1.2f\n", VERSION);
	printf("Usage:\n"
	       "ssdd <options>\n\n"
	       "-f       --forks=NUM       number of forks\n"
	       "-h       --help            print this message\n"
	       "         --json=FILENAME   write final results into FILENAME, JSON formatted\n"
	       "-q       --quiet           suppress running output\n"
	       "-i       --iters=NUM       number of iterations, NUM must be at least 1\n"
	       );
	exit(error);
}

static int do_wait(pid_t *wait_pid, int *ret_sig)
{
	int status, child_status;

	*ret_sig = -1; /* initially mark 'nothing returned' */

	while (1) {
		status = waitpid(-1, &child_status, WUNTRACED | __WALL);
		if (status == -1) {
			if (errno == EINTR)
				continue;
			if (errno == ECHILD) {
				*wait_pid = (pid_t)0;
				return STATE_ECHILD;
			}
			printf("do_wait/%d: EXITING, ERROR: "
			       "waitpid() returned errno %d\n",
			       getpid(), errno);
			exit(1);
		}
		break;
	}
	*wait_pid = (pid_t)status;

	if (WIFEXITED(child_status)) {
		if (WIFSIGNALED(child_status))
			return STATE_EXITED_TSIG;
		if (WEXITSTATUS(child_status))
			return STATE_EXITED_ERRSTAT;
		return STATE_EXITED;
	}
	if (WIFSTOPPED(child_status)) {
		*ret_sig = WSTOPSIG(child_status);
		return STATE_STOPPED;
	}
	if (WIFSIGNALED(child_status)) {
		*ret_sig = WTERMSIG(child_status);
		return STATE_SIGNALED;
	}
	return STATE_UNKNOWN;
}

static int check_sigchld(sigset_t *set)
{

	struct timespec timeout;

	timeout.tv_sec = 10;
	timeout.tv_nsec = 0;
	int recv_sig = 0;

	/*
	 * Check the handler flag, then if need be, wait for the signal to
	 * arrive
	 */
	if (!got_sigchld)
		recv_sig = sigtimedwait(set, NULL, &timeout);

	if (sigprocmask(SIG_UNBLOCK, set, NULL) == -1) {
		printf("EXITING, ERROR: unable to mask signal set\n");
		exit(1);
	}

	if (recv_sig == -1) {
		printf("EXITING, ERROR: Timeout: no signal received in 10 seconds\n");
		exit(1);
	} else if (recv_sig == SIGCHLD) {
		got_sigchld = 1;
	}

	return got_sigchld;
}

static pid_t parent;
static int nforks = 10;
static int nsteps = 10000;

static void sigchld(int sig, siginfo_t *info, void *arg)
{
	got_sigchld = 1;
}

static void child_process(void)
{
	while (1)
		;
}

static int forktests(int testid)
{
	int i, status, ret_sig;
	long pstatus;
	pid_t child, wait_pid;
	struct sigaction act, oact;

	parent = getpid();

	child = fork();
	if (child == -1) {
		printf("forktest#%d/%d: EXITING, ERROR: "
		       "fork returned errno %d\n", testid, parent, errno);
		exit(1);
	}
	if (!child)
		child_process();

	if (!quiet)
		printf("forktest#%d/%d/%d: STARTING\n", testid, parent, child);

	act.sa_sigaction = sigchld;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_SIGINFO;
	status = sigaction(SIGCHLD, &act, &oact);
	if (status) {
		printf("forktest#%d/%d: EXITING, ERROR: "
		       "sigaction returned %d, errno %d\n",
		       testid, parent, status, errno);
		exit(1);
	}

	/*
	 * Block the signal before it is generated
	 * Ensures we can synchronously wait for it.
	 */
	sigset_t set;

	sigemptyset(&set);
	sigaddset(&set, SIGCHLD);

	if (sigprocmask(SIG_BLOCK, &set, NULL) == -1) {
		printf("EXITING, ERROR: unable to mask signal set\n");
		exit(1);
	}

	/*
	 * Attach to the child.
	 */
	pstatus = ptrace(PTRACE_ATTACH, child, NULL, NULL);
	if (pstatus == ~0l) {
		printf("forktest#%d/%d: EXITING, ERROR: "
		       "attach failed.  errno %d\n",
		       testid, getpid(), errno);
		exit(1);
	}

	/*
	 * The attach should cause the child to receive a signal.
	 */
	status = do_wait(&wait_pid, &ret_sig);
	if (wait_pid != child) {
		printf("forktest#%d/%d: EXITING, ERROR: "
		       "attach: Unexpected wait pid %d\n",
		       testid, getpid(), wait_pid);
		exit(1);
	}
	if (status != STATE_STOPPED) {
		printf("forktest#%d/%d: EXITING, ERROR: "
		       "attach: wait on PTRACE_ATTACH returned %d "
		       "[%s, wanted STATE_STOPPED], signo %d\n",
		       testid, getpid(), status, get_state_name(status),
		       ret_sig);
		exit(1);
	}
	if (!check_sigchld(&set)) {
		printf("forktest#%d/%d: EXITING, ERROR: "
		       "wait on PTRACE_ATTACH saw a SIGCHLD count of %d, should be 1\n",
		       testid, getpid(), got_sigchld);
		exit(1);
	}
	got_sigchld = 0;


	/*
	 * Generate 'nsteps' PTRACE_SINGLESTEPs, make sure they all actually
	 * step the tracee.
	 */
	for (i = 0; i < nsteps; i++) {

		if (sigprocmask(SIG_BLOCK, &set, NULL) == -1) {
			printf("EXITING, ERROR: unable to mask signal set\n");
			exit(1);
		}

		pstatus = ptrace(PTRACE_SINGLESTEP, child, NULL, NULL);

		if (pstatus) {
			printf("forktest#%d/%d: EXITING, ERROR: "
			       "PTRACE_SINGLESTEP #%d: returned status %ld, "
			       "errno %d, signo %d\n",
			       testid, getpid(), i, pstatus, errno, ret_sig);
			exit(1);
		}

		status = do_wait(&wait_pid, &ret_sig);
		if (wait_pid != child) {
			printf("forktest#%d/%d: EXITING, ERROR: "
			       "wait on PTRACE_SINGLESTEP #%d: returned wrong pid %d, "
			       "expected %d\n",
			       testid, getpid(), i, wait_pid, child);
			exit(1);
		}
		if (status != STATE_STOPPED) {
			printf("forktest#%d/%d: EXITING, ERROR: "
			       "wait on PTRACE_SINGLESTEP #%d: wanted STATE_STOPPED, "
			       "saw %s instead (and saw signo %d too)\n",
			       testid, getpid(), i,
			       get_state_name(status), ret_sig);
			exit(1);
		}
		if (ret_sig != SIGTRAP) {
			printf("forktest#%d/%d: EXITING, ERROR: "
			       "wait on PTRACE_SINGLESTEP #%d: returned signal %d, "
			       "wanted SIGTRAP\n",
			       testid, getpid(), i, ret_sig);
			exit(1);
		}
		if (!check_sigchld(&set)) {
			printf("forktest#%d/%d: EXITING, ERROR: "
			       "wait on PTRACE_SINGLESTEP #%d: no SIGCHLD seen "
			       "(signal count == 0), signo %d\n",
			       testid, getpid(), i, ret_sig);
			exit(1);
		}
		got_sigchld = 0;
	}

	/* There is no need for the tracer to kill the tracee. It will
	 * automatically exit when its owner, ie, us, exits.
	 */
	if (!quiet)
		printf("forktest#%d/%d: EXITING, no error\n", testid, parent);
	exit(0);
}

int main(int argc, char **argv)
{
	int i, ret_sig, status;
	pid_t child = 0, wait_pid;
	int error = 0;

	setbuf(stdout, NULL);

	rt_init(argc, argv);
	for (;;) {
		int option_index = 0;

		static struct option long_options[] = {
			{"forks",		required_argument,	NULL, OPT_NFORKS},
			{"help",		no_argument,		NULL, OPT_HELP},
			{"json",		required_argument,	NULL, OPT_JSON},
			{"quiet",		no_argument,		NULL, OPT_QUIET},
			{"iters",		required_argument,	NULL, OPT_NITERS},
			{NULL, 0, NULL, 0},
		};
		int c = getopt_long(argc, argv, "f:hqi:", long_options, &option_index);
		if (c == -1)
			break;
		switch(c) {
		case 'f':
		case OPT_NFORKS:
			nforks = atoi(optarg);
			break;
		case 'h':
		case OPT_HELP:
			usage(0);
			break;
		case OPT_JSON:
			strncpy(jsonfile, optarg, strnlen(optarg, MAX_PATH-1));
			break;
		case OPT_QUIET:
		case 'q':
			quiet = 1;
			break;
		case 'i':
		case OPT_NITERS:
			nsteps = atoi(optarg);
			if (nsteps < 1) {
				usage(0);
			}
			break;
		default:
			usage(1);
			break;
		}
	}

	if (!quiet) {
		printf("#main : %d\n", getpid());
		printf("#forks: %d\n", nforks);
		printf("#steps: %d\n", nsteps);
		printf("\n");
	}

	for (i = 0; i < nforks; i++) {
		child = fork();
		if (child == -1) {
			printf("main: fork returned errno %d\n", errno);
			exit(1);
		}
		if (!child)
			forktests(i);
	}

	for (i = 0; i < nforks; i++) {
		status = do_wait(&wait_pid, &ret_sig);
		if (status != STATE_EXITED) {
			if (0) printf("main/%d: ERROR: "
			       "forktest#%d unexpected do_wait status %d "
			       "[%s, wanted STATE_EXITED]\n",
			       getpid(), wait_pid, status,
			       get_state_name(status));
			error = 1;
		}
	}

	printf("%s.\n", error ?
		"One or more tests FAILED" :
		"All tests PASSED");

	if (strlen(jsonfile) != 0)
		rt_write_json(jsonfile, error, NULL, NULL);

	exit(error);
}
