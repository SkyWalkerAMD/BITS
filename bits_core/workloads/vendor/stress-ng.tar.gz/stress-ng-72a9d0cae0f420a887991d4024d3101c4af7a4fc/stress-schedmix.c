/*
 * Copyright (C) 2023-2026 Colin Ian King.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */
#include "stress-ng.h"
#include "core-affinity.h"
#include "core-builtin.h"
#include "core-capabilities.h"
#include "core-killpid.h"
#include "core-mmap.h"
#include "core-prime.h"
#include "core-sched.h"

#include <sched.h>
#include <time.h>
#include <sys/times.h>

#if defined(HAVE_LINUX_MEMBARRIER_H)
#include <linux/membarrier.h>
#endif
#if defined(HAVE_SEMAPHORE_H)
#include <semaphore.h>
#endif
#if defined(HAVE_SYS_SELECT_H)
#include <sys/select.h>
#endif

#if defined(HAVE_SEMAPHORE_H) && \
    defined(HAVE_LIB_PTHREAD) && \
    defined(HAVE_SEM_POSIX) &&	 \
    defined(CLOCK_REALTIME)
#define HAVE_SCHEDMIX_SEM
#endif

#define MIN_SCHEDMIX_PROCS	(1)
#define MAX_SCHEDMIX_PROCS	(64)
#define DEFAULT_SCHEDMIX_PROCS	(16)

static const stress_help_t help[] = {
	{ NULL,	"schedmix N",		"start N workers that exercise a mix of scheduling loads" },
	{ NULL, "schedmix-cpumix",	"randomly mix child processes to different CPUs" },
	{ NULL,	"schedmix-ops N",	"stop after N schedmix bogo operations" },
	{ NULL, "schedmix-procs N",	"select number of schedmix child processes 1..64" },
	{ NULL,	NULL,			NULL }
};

static const stress_opt_t opts[] = {
	{ OPT_schedmix_cpumix, "schedmix-cpumix", TYPE_ID_BOOL, 0, 1, NULL },
	{ OPT_schedmix_procs,  "schedmix-procs",  TYPE_ID_SIZE_T, MIN_SCHEDMIX_PROCS, MAX_SCHEDMIX_PROCS, NULL },
	END_OPT,
};

#if (defined(_POSIX_PRIORITY_SCHEDULING) || defined(__linux__)) &&	\
     !defined(__OpenBSD__) &&						\
     !defined(__minix__) &&						\
     !defined(__APPLE__) &&						\
     !defined(__HAIKU__) &&						\
     !defined(__serenity__)

#if defined(HAVE_SCHEDMIX_SEM)
typedef struct {
	sem_t sem;
	pid_t owner;
} stress_schedmix_sem_t;

static stress_schedmix_sem_t *schedmix_sem;
#endif

/*
 *  stress_schedmix_setaffinity()
 *	attempt to set CPU affinity of current process to cpu
 *	and don't care if it fails
 */
static void stress_schedmix_setaffinity(const pid_t pid, const int cpu)
{
#if defined(HAVE_SCHED_SETAFFINITY) && \
    defined(HAVE_CPU_SET_T)
	cpu_set_t cpu_set;

	CPU_ZERO(&cpu_set);
	CPU_SET(cpu, &cpu_set);
	VOID_RET(int, sched_setaffinity(pid, sizeof(cpu_set), &cpu_set));
#else
	(void)pid;
	(void)cpu;
#endif
}

static inline void stress_schedmix_waste_time(
	stress_args_t *args,
	const uint32_t n_cpus,
	const uint32_t *cpus)
{
	int i;
	int n;
	int status;
	pid_t pid;
	stress_load_average_info_t load_average_info;
	struct tms tms_buf;
#if defined(HAVE_GETRUSAGE) &&	\
    (defined(RUSAGE_SELF) || defined(RUSAGE_CHILDREN))
	struct rusage usage;
#endif
#if defined(HAVE_SCHEDMIX_SEM)
	struct timespec timeout;
#endif
#if defined(HAVE_SYS_SELECT_H) &&       \
    (defined(HAVE_SELECT) ||		\
     defined(HAVE_PSELECT))
	fd_set rfds;
	const int fdstdin = fileno(stdin);
#endif
#if defined(HAVE_SYS_SELECT_H) &&       \
    defined(HAVE_SELECT)
	struct timeval tv;
#endif
#if defined(HAVE_SYS_SELECT_H) &&       \
    defined(HAVE_PSELECT)
	struct timespec ts;
	sigset_t sigmask;
#endif
redo:
	n = stress_mwc8modn(28);
	switch (n) {
	case 0:
		(void)shim_sched_yield();
		break;
	case 1:
		n = stress_mwc16();
		for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++)
			(void)shim_sched_yield();
		break;
	case 2:
		(void)shim_nanosleep_uint64(stress_mwc32modn(1000000));
		break;
	case 3:
		n = stress_mwc8();
		for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++)
			(void)shim_nanosleep_uint64(stress_mwc32modn(10000));
		break;
	case 4:
		for (i = 0; LIKELY(stress_continue(args) && (i < 1000000)); i++)
			stress_asm_nop();
		break;
	case 5:
		n = stress_mwc32modn(1000000);
		for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++)
			stress_asm_nop();
		break;
	case 6:
		for (i = 0; LIKELY(stress_continue(args) && (i < 10000)); i++)
			VOID_RET(double, stress_time_now());
		break;
	case 7:
		n = stress_mwc16modn(10000);
		for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++)
			VOID_RET(double, stress_time_now());
		break;
	case 8:
		for (i = 0; LIKELY(stress_continue(args) && (i < 1000)); i++)
			VOID_RET(int, shim_nice(0));
		break;
	case 9:
		n = stress_mwc16modn(1000);
		for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++)
			VOID_RET(int, shim_nice(0));
		break;
	case 10:
		for (i = 0; LIKELY(stress_continue(args) && (i < 10)); i++)
			VOID_RET(uint64_t, stress_prime64_get(stress_mwc8()));
		break;
	case 11:
		for (i = 0; LIKELY(stress_continue(args) && (i < 1000)); i++)
			getpid();
		break;
	case 12:
		n = stress_mwc16modn(1000);
		for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++)
			getpid();
		break;
	case 13:
		for (i = 0; LIKELY(stress_continue(args) && (i < 1000)); i++)
			(void)sleep(0);
		break;
	case 14:
		n = stress_mwc16modn(1000);
		for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++)
			(void)sleep(0);
		break;
	case 15:
		n = stress_mwc16modn(1000);
		for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++) {
			(void)shim_sched_yield();
			(void)sleep(0);
			VOID_RET(int, shim_nice(0));
			(void)shim_nanosleep_uint64(stress_mwc32modn(1000));
		}
		break;
	case 16:
		getpid();
		break;
	case 17:
		(void)shim_usleep_interruptible(1000);
		break;
	case 18:
#if defined(HAVE_LINUX_MEMBARRIER_H) &&	\
    defined(MEMBARRIER_CMD_GLOBAL)
		if (shim_membarrier(MEMBARRIER_CMD_GLOBAL, 0, 0) == 0)
			break;
#endif
		getpid();
		break;
	case 19:
		VOID_RET(int, stress_load_average_get(&load_average_info));
		break;
	case 20:
		pid = fork();
		if (pid == 0) {
			_exit(0);
		} else if (pid > 0) {
			VOID_RET(pid_t, shim_waitpid(pid, &status, 0));
		}
		break;
	case 21:
#if defined(HAVE_GETRUSAGE)
#if defined(RUSAGE_SELF)
		VOID_RET(int, shim_getrusage(RUSAGE_SELF, &usage));
#endif
#if defined(RUSAGE_CHILDREN)
		VOID_RET(int, shim_getrusage(RUSAGE_CHILDREN, &usage));
#endif
#endif
		VOID_RET(clock_t, times(&tms_buf));
		break;
#if defined(__linux__)
	case 22:
		(void)stress_fs_discard("/proc/pressure/cpu");
		break;
	case 23:
		(void)stress_fs_discard("/proc/self/schedstat");
		break;
#endif
#if defined(HAVE_SCHEDMIX_SEM)
	case 24:
		if (UNLIKELY(clock_gettime(CLOCK_REALTIME, &timeout) < 0))
			break;
		timeout.tv_nsec += 1000000;
		if (timeout.tv_nsec > 1000000000) {
			timeout.tv_nsec -= 1000000000;
			timeout.tv_sec++;
		}
		if (UNLIKELY(sem_timedwait(&schedmix_sem->sem, &timeout) < 0)) {
			/*
			 *  can't get semaphore, then stop/continue process
			 *  that currently holds it
			 */
			pid = schedmix_sem->owner;
			if (pid > 1) {
				(void)kill(pid, SIGSTOP);
				(void)shim_sched_yield();
				(void)kill(pid, SIGCONT);
			}
		} else {
			/*
			 *  got semaphore, kill some cycles and release it
			 */
			schedmix_sem->owner = getpid();
			n = stress_mwc16();
			for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++)
				(void)shim_sched_yield();
			schedmix_sem->owner = -1;
			(void)sem_post(&schedmix_sem->sem);
		}
		break;
#endif
#if defined(HAVE_SYS_SELECT_H) &&       \
    defined(HAVE_SELECT)
	case 25:
		if (LIKELY((fdstdin >= 0) && (fdstdin < FD_SETSIZE))) {
			FD_ZERO(&rfds);
			FD_SET(fdstdin, &rfds);
			tv.tv_sec = 0;
			tv.tv_usec = 100;
			(void)select(fdstdin + 1, &rfds, NULL, NULL, &tv);
		}
		break;
#endif
#if defined(HAVE_SYS_SELECT_H) &&       \
    defined(HAVE_PSELECT) &&		\
    defined(FD_SETSIZE)
	case 26:
		if (LIKELY((fdstdin >= 0) && (fdstdin < FD_SETSIZE))) {
			FD_ZERO(&rfds);
			FD_SET(fdstdin, &rfds);
			ts.tv_sec = 0;
			ts.tv_nsec = 100000;
			(void)sigemptyset(&sigmask);
			(void)pselect(fdstdin + 1, &rfds, NULL, NULL, &ts, &sigmask);
		}
		break;
#endif
	case 27:
		if (cpus) {
			pid = getpid();
			n = stress_mwc8modn(32);
			for (i = 0; LIKELY(stress_continue(args) && (i < n)); i++) {
				const uint32_t idx = stress_mwc32modn(n_cpus);

				stress_schedmix_setaffinity(pid, cpus[idx]);
			}
		}
		break;
	default:
		goto redo;
	}
}

#if defined(HAVE_SETITIMER) &&	\
    defined(ITIMER_PROF)
static inline void stress_schedmix_itimer_set(void)
{
	struct itimerval timer;

	timer.it_value.tv_sec = 0;
	timer.it_value.tv_usec = 10000 + stress_mwc32modn(10000);
	timer.it_interval.tv_sec = 0;
	timer.it_interval.tv_usec = timer.it_value.tv_usec;
	VOID_RET(int, setitimer(ITIMER_PROF, &timer, NULL));
}

static inline void stress_schedmix_itimer_clear(void)
{
	struct itimerval timer;

	(void)shim_memset(&timer, 0, sizeof(timer));
	VOID_RET(int, setitimer(ITIMER_PROF, &timer, NULL));
}

static void MLOCKED_TEXT stress_schedmix_itimer_handler(int signum)
{
	const int saved_errno = errno;

	(void)signum;

	stress_schedmix_itimer_set();

	errno = saved_errno;
}
#endif

static int stress_schedmix_child(
	stress_args_t *args,
	const uint32_t n_cpus,
	const uint32_t *cpus)
{
	int old_policy = -1;
	int rc = EXIT_SUCCESS;
	const pid_t child_pid = getpid();

#if defined(HAVE_SETITIMER) &&	\
    defined(ITIMER_PROF)
	if (stress_signal_handler(args->name, SIGPROF, stress_schedmix_itimer_handler, NULL) == 0)
		stress_schedmix_itimer_set();
#endif

	do {
#if defined(SCHED_DEADLINE) &&		\
    defined(HAVE_SCHED_GETATTR) &&	\
    defined(HAVE_SCHED_SETATTR)
		struct shim_sched_attr attr;
#else
		UNEXPECTED
#endif
		struct sched_param param;
		int ret = 0;
		int policy;
		int max_prio;
		int min_prio;
		int rng_prio;
		int new_policy;
		const pid_t pid = stress_mwc1() ? 0 : args->pid;
		const char *new_policy_name;

		/*
		 *  find a new randomized policy that is not the same
		 *  as the previous old policy
		 */
		do {
			policy = stress_mwc8modn((uint8_t)stress_sched_types_length);
		} while (policy == old_policy);
		old_policy = policy;

		new_policy = stress_sched_types[policy].sched;
		new_policy_name = stress_sched_types[policy].sched_name;

		if (UNLIKELY(!stress_continue(args)))
			break;

		errno = 0;
		switch (new_policy) {
#if defined(SCHED_DEADLINE) &&		\
    defined(HAVE_SCHED_GETATTR) &&	\
    defined(HAVE_SCHED_SETATTR)
		case SCHED_DEADLINE:
			/*
			 *  Only have 1 RT deadline instance running
			 */
			if (stress_instance_zero(args)) {
				uint64_t rndtime = (uint64_t)stress_mwc8modn(64) + 32;

				(void)shim_memset(&attr, 0, sizeof(attr));
				attr.size = sizeof(attr);
#if defined(SCHED_FLAG_DL_OVERRUN) &&	\
    defined(SIGXCPU)
				attr.sched_flags = SCHED_FLAG_DL_OVERRUN;
#else
				attr.sched_flags = 0;
#endif
				attr.sched_nice = 0;
				attr.sched_priority = 0;
				attr.sched_policy = SCHED_DEADLINE;
				/* runtime <= deadline <= period */
				attr.sched_runtime = rndtime * 1000000;
				attr.sched_deadline = rndtime * 2000000;
				attr.sched_period = rndtime * 4000000;

				ret = shim_sched_setattr(0, &attr, 0);
			} else {
#if defined(SCHED_IDLE)
				new_policy = SCHED_IDLE;
#elif defined(SCHED_BATCH)
				new_policy = SCHED_BATCH;
#elif defined(SCHED_OTHER)
				new_policy = SCHED_OTHER;
#else
				/* give up, default to zero */
				new_policy = 0;
#endif
			}
			param.sched_priority = 0;
			(void)sched_setscheduler(pid, new_policy, &param);
			break;
#endif
#if defined(SCHED_IDLE)
		case SCHED_IDLE:
#endif
#if defined(SCHED_BATCH)
		case SCHED_BATCH:
#endif
#if defined(SCHED_EXT)
		case SCHED_EXT:
#endif
#if defined(SCHED_OTHER)
		case SCHED_OTHER:
#endif
			param.sched_priority = 0;
			ret = sched_setscheduler(pid, new_policy, &param);

			break;
#if defined(SCHED_RR)
		case SCHED_RR:
#if defined(HAVE_SCHED_RR_GET_INTERVAL)
			{
				struct timespec t;

				VOID_RET(int, sched_rr_get_interval(pid, &t));
			}
#endif
#define NEED_CASE_SCHED_FIFO
			goto case_sched_fifo;
#endif
#if defined(SCHED_FIFO)
		case SCHED_FIFO:
#endif
#if defined(NEED_CASE_SCHED_FIFO)
case_sched_fifo:
#endif
			min_prio = sched_get_priority_min(new_policy);
			max_prio = sched_get_priority_max(new_policy);

			/* Check if min/max is supported or not */
			if ((min_prio == -1) || (max_prio == -1))
				continue;

			rng_prio = max_prio - min_prio;
			if (UNLIKELY(rng_prio == 0)) {
				pr_err("%s: invalid min/max priority "
					"range for scheduling policy %s "
					"(min=%d, max=%d)\n",
					args->name,
					new_policy_name,
					min_prio, max_prio);
				break;
			}
			param.sched_priority = (int)stress_mwc32modn(rng_prio) + min_prio;
			ret = sched_setscheduler(pid, new_policy, &param);
			break;
		default:
			goto next;
		}
		if (UNLIKELY(ret < 0)) {
			/*
			 *  Some systems return EINVAL for non-POSIX
			 *  scheduling policies, silently ignore these
			 *  failures.
			 */
			if ((errno != EPERM) &&
			    (errno != EINVAL) &&
			    (errno != EINTR) &&
			    (errno != ENOSYS) &&
			    (errno != EBUSY)) {
				pr_fail("%s: sched_setscheduler "
					"failed, errno=%d (%s) "
					"for scheduler policy %s\n",
					args->name, errno, strerror(errno),
					new_policy_name);
				rc = EXIT_FAILURE;
			}
		}
		stress_schedmix_waste_time(args, n_cpus, cpus);
		stress_bogo_inc(args);
next:
		if (cpus) {
			const uint32_t idx = stress_mwc32modn(n_cpus);

			stress_schedmix_setaffinity(child_pid, cpus[idx]);
		}
	} while (stress_continue(args));

#if defined(HAVE_SETITIMER) &&	\
    defined(ITIMER_PROF)
	stress_schedmix_itimer_clear();
#endif

	return rc;
}

static int stress_schedmix(stress_args_t *args)
{
	stress_pid_t *s_pids;
	stress_pid_t *s_pids_head = NULL;
	size_t i;
	size_t schedmix_procs = DEFAULT_SCHEDMIX_PROCS;
	int rc;
	const int parent_cpu = stress_cpu_get();
	uint32_t *cpus = NULL;
	uint32_t n_cpus = 0;
	bool schedmix_cpumix = false;

	(void)stress_setting_get("schedmix-cpumix", &schedmix_cpumix);
	if (schedmix_cpumix) {
#if defined(HAVE_SCHED_SETAFFINITY) && \
    defined(HAVE_CPU_SET_T)
		n_cpus = stress_affinity_cpus_get(&cpus, true);
#else
		if (stress_instance_zero(args))
			pr_inf("%s: no support of setting CPU affinity, "
			       "disabling option schedmix-cpumix\n", args->name);
#endif
	}

	if (stress_sched_types_length == (0)) {
		if (stress_instance_zero(args)) {
			pr_inf_skip("%s: no scheduling policies "
				"available, skipping stressor\n",
				args->name);
		}
		rc = EXIT_NOT_IMPLEMENTED;
		goto free_cpus;
	}

#if defined(SCHED_FLAG_DL_OVERRUN) &&	\
    defined(SIGXCPU)
	if (stress_signal_handler(args->name, SIGXCPU, stress_signal_ignore_handler, NULL) < 0) {
		rc = EXIT_FAILURE;
		goto free_cpus;
	}
#endif

	s_pids = stress_sync_s_pids_mmap(MAX_SCHEDMIX_PROCS);
	if (s_pids == MAP_FAILED) {
		pr_inf_skip("%s: mmap %d PIDs failed%s, skipping stressor\n",
			args->name, MAX_SCHEDMIX_PROCS, stress_memory_free_get());
		rc = EXIT_NO_RESOURCE;
		goto free_cpus;
	}

#if defined(HAVE_SCHEDMIX_SEM)
	schedmix_sem = (stress_schedmix_sem_t *)
		stress_mmap_populate(NULL, sizeof(*schedmix_sem),
			PROT_READ | PROT_WRITE,
			MAP_SHARED | MAP_ANONYMOUS, -1, 0);
	if (schedmix_sem != MAP_FAILED) {
		stress_memory_anon_name_set(schedmix_sem, sizeof(*schedmix_sem), "semaphores");
		if (sem_init(&schedmix_sem->sem, 0, 1) < 0) {
			(void)munmap((void *)schedmix_sem, sizeof(*schedmix_sem));
			schedmix_sem = NULL;
		}
	} else {
		schedmix_sem = NULL;
	}
#endif

	if (!stress_setting_get("schedmix-procs", &schedmix_procs)) {
		if (g_opt_flags & OPT_FLAGS_MAXIMIZE)
			schedmix_procs = MAX_SCHEDMIX_PROCS;
		if (g_opt_flags & OPT_FLAGS_MINIMIZE)
			schedmix_procs = MIN_SCHEDMIX_PROCS;
	}

	for (i = 0; i < schedmix_procs; i++) {
		stress_sync_start_init(&s_pids[i]);

		stress_mwc_reseed();

		s_pids[i].pid = fork();
		if (s_pids[i].pid < 0) {
			continue;
		} else if (s_pids[i].pid == 0) {
			stress_proc_state_set(args->name, STRESS_STATE_SYNC_WAIT);
			s_pids[i].pid = getpid();
			stress_sync_start_wait_s_pid(&s_pids[i]);
			stress_proc_state_set(args->name, STRESS_STATE_RUN);
			stress_make_it_fail_set();

			VOID_RET(int, shim_nice(stress_mwc8modn(7)));
			stress_parent_died_alarm();
			(void)stress_affinity_change_cpu(args, parent_cpu);
			_exit(stress_schedmix_child(args, n_cpus, cpus));
		} else {
			stress_sync_start_s_pid_list_add(&s_pids_head, &s_pids[i]);
		}
	}

	stress_proc_state_set(args->name, STRESS_STATE_SYNC_WAIT);
	stress_sync_start_wait(args);
	stress_sync_start_cont_list(s_pids_head);
	stress_proc_state_set(args->name, STRESS_STATE_RUN);

	do {
		if (schedmix_cpumix && cpus) {
			const uint32_t idx = stress_mwc32modn(n_cpus);

			i = stress_mwcsizemodn(schedmix_procs);
			stress_schedmix_setaffinity(s_pids[i].pid, cpus[idx]);
			if (stress_continue(args))
				stress_random_small_sleep();
		} else {
			(void)shim_pause();
		}
	} while (stress_continue(args));

	stress_proc_state_set(args->name, STRESS_STATE_DEINIT);

#if defined(HAVE_SCHEDMIX_SEM)
	if (schedmix_sem) {
		(void)sem_destroy(&schedmix_sem->sem);
		(void)munmap((void *)schedmix_sem, sizeof(*schedmix_sem));
	}
#endif

	rc = stress_kill_and_wait_many(args, s_pids, schedmix_procs, SIGALRM, true);

	(void)stress_sync_s_pids_munmap(s_pids, MAX_SCHEDMIX_PROCS);

free_cpus:
	if (cpus)
		free(cpus);

	return rc;
}

static const stress_exercises_t exercises[] = {
	STRESS_EX_FEATURE("chaotic-load"),
	STRESS_EX_FEATURE("interrupt"),
	STRESS_EX_FEATURE("load-average"),
	STRESS_EX_FEATURE("rcu-utilization"),

	STRESS_EX_SYSCALL("fork"),
#if defined(HAVE_GETRUSAGE)
	STRESS_EX_SYSCALL("getrusage"),
#endif
	STRESS_EX_SYSCALL("gettimeofday"),
	STRESS_EX_SYSCALL("nanosleep"),
#if defined(HAVE_SYS_SELECT_H) &&       \
    defined(HAVE_PSELECT) &&		\
    defined(FD_SETSIZE)
	STRESS_EX_SYSCALL("pselect"),
#endif
	STRESS_EX_SYSCALL("sched_setaffinity"),
	STRESS_EX_SYSCALL("sched_yield"),
#if defined(HAVE_SYS_SELECT_H) &&       \
    defined(HAVE_SELECT)
	STRESS_EX_SYSCALL("select"),
#endif
#if defined(HAVE_SCHEDMIX_SEM)
	STRESS_EX_SYSCALL("clock_gettime"),
	STRESS_EX_SYSCALL("sem_timedwait"),
	STRESS_EX_SYSCALL("sem_post"),
#endif
	STRESS_EX_SYSCALL("sleep"),
	STRESS_EX_SYSCALL("times"),
	STRESS_EX_SYSCALL("waitpid"),

	STRESS_EX_END,
};

const stressor_info_t stress_schedmix_info = {
	.stressor = stress_schedmix,
	.classifier = CLASS_INTERRUPT | CLASS_SCHEDULER | CLASS_OS,
	.opts = opts,
	.verify = VERIFY_ALWAYS,
	.help = help,
	.exercises = exercises,
};
#else
const stressor_info_t stress_schedmix_info = {
	.stressor = stress_unimplemented,
	.classifier = CLASS_INTERRUPT | CLASS_SCHEDULER | CLASS_OS,
	.opts = opts,
	.verify = VERIFY_ALWAYS,
	.help = help,
	.unimplemented_reason = "built without Linux scheduling support"
};
#endif
