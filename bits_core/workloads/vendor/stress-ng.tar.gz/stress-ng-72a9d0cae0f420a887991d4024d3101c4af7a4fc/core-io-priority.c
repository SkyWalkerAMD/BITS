/*
 * Copyright (C) 2013-2021 Canonical, Ltd.
 * Copyright (C) 2022-2026 Colin Ian King.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */
#include "stress-ng.h"
#include "core-builtin.h"
#include "core-io-priority.h"

/*
 *  stress_io_priority_ionice_class_get
 *	string io scheduler to IOPRIO_CLASS
 */
int32_t stress_io_priority_ionice_class_get(const char *const str)
{
#if defined(IOPRIO_CLASS_IDLE)
	if (!shim_strcmp("idle", str))
		return IOPRIO_CLASS_IDLE;
#endif
#if defined(IOPRIO_CLASS_BE)
	if (!shim_strcmp("besteffort", str) ||
	    !shim_strcmp("be", str))
		return IOPRIO_CLASS_BE;
#endif
#if defined(IOPRIO_CLASS_RT)
	if (!shim_strcmp("realtime", str) ||
	    !shim_strcmp("rt", str))
		return IOPRIO_CLASS_RT;
#endif
	if (shim_strcmp("which", str))
		(void)fprintf(stderr, "invalid ionice-class option: %s\n", str);

	(void)fprintf(stderr, "available options are:");
#if defined(IOPRIO_CLASS_IDLE)
	(void)fprintf(stderr, " idle");
#endif
#if defined(IOPRIO_CLASS_BE)
	(void)fprintf(stderr, " besteffort be");
#endif
#if defined(IOPRIO_CLASS_RT)
	(void)fprintf(stderr, " realtime rt");
#endif
	(void)fprintf(stderr, "\n");

	_exit(EXIT_FAILURE);
	return 0;
}

#if defined(__NR_ioprio_set)
/*
 *  stress_io_priority_set()
 *	check ioprio settings and set
 */
int stress_io_priority_set(const int32_t ioprio_class, const int32_t level)
{
	int new_level = level;
	int rc;

	switch (ioprio_class) {
	case UNDEFINED:	/* No preference, don't set */
		return 0;
	case IOPRIO_CLASS_RT:
	case IOPRIO_CLASS_BE:
		if (new_level == UNDEFINED)
			new_level = 0;
		if ((new_level < 0) || (new_level > 7)) {
			(void)pr_err("--ionice-level priority levels range from "
				"0 (highest priority) to 7 (lowest priority) "
				"for realtime or besteffort --ionice classes\n");
			return -1;
		}
		break;
	case IOPRIO_CLASS_IDLE:
		if ((new_level != UNDEFINED) &&
		    (new_level != 0))
			(void)pr_inf("cannot set priority level with --ionice-class idle, defaulting to 0\n");
		new_level = 0;
		break;
	default:
		(void)pr_err("--ionice-class: unknown priority class: %d\n", ioprio_class);
		return -1;
	}
	rc = shim_ioprio_set(IOPRIO_WHO_PROCESS, 0,
		IOPRIO_PRIO_VALUE(ioprio_class, new_level));
	if ((rc < 0) && (errno != ENOSYS)) {
		(void)pr_err("cannot set I/O priority, errno=%d (%s)\n",
			errno, strerror(errno));
		return -1;
	}
	return 0;
}
#else
int stress_io_priority_set(const int32_t ioprio_class, const int32_t level)
{
	(void)ioprio_class;
	(void)level;

	return 0;
}
#endif
