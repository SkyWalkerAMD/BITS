/*
 * Copyright (C) 2013-2021 Canonical, Ltd.
 * Copyright (C) 2022-2026 Colin Ian King.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */
#include "stress-ng.h"
#include "core-builtin.h"
#include "core-madvise.h"
#include "core-mmap.h"
#include "core-pragma.h"
#include "core-signal.h"
#include "core-sort.h"
#include "core-target-clones.h"

#define THRESH 63

#define MIN_QSORT_SIZE		(1 * STRESS_KB)
#define MAX_QSORT_SIZE		(4 * STRESS_MB)
#define DEFAULT_QSORT_SIZE	(256 * STRESS_KB)

#if defined(HAVE_SIGLONGJMP)
static volatile bool do_jmp = true;
static sigjmp_buf jmp_env;
#endif

typedef int (*comp_func_t)(const void *v1, const void *v2);
typedef void (*qsort_func_t)(void *base, size_t nmemb, size_t size, comp_func_t cmp);

static const stress_help_t help[] = {
	{ "Q N", "qsort N",		"start N workers qsorting 32 bit random integers" },
	{ NULL,	"qsort-method M",	"select qsort method [ qsort-libc | qsort_bm ]" },
	{ NULL,	"qsort-ops N",		"stop after N qsort bogo operations" },
	{ NULL,	"qsort-size N",		"number of 32 bit integers to sort" },
	{ NULL,	NULL,			NULL }
};

typedef struct {
	const char *name;
	const qsort_func_t qsort_func;
} stress_qsort_method_t;

typedef uint32_t qsort_swap_type_t;

#define ALIGN_SWAP_TYPE(ptr)	shim_assume_aligned(ptr, sizeof(qsort_swap_type_t))

#if defined(HAVE_SIGLONGJMP)
/*
 *  stress_qsort_handler()
 *	SIGALRM generic handler
 */
static void MLOCKED_TEXT stress_qsort_handler(int signum)
{
	stress_signal_siglongjmp_flag(signum, jmp_env, 1, &do_jmp);
}
#endif

static const stress_qsort_method_t stress_qsort_methods[] = {
#if defined(HAVE_QSORT)
	{ "qsort-libc",		qsort },
#endif
	{ "qsort-bm",		qsort_bm },
};

static inline bool OPTIMIZE3 stress_qsort_verify_forward(
	stress_args_t *args,
	const int32_t *data,
	const size_t n,
	CLOBBERED int *rc)
{
	if (g_opt_flags & OPT_FLAGS_VERIFY) {
		register const int32_t *ptr = data;
		register const int32_t *end = data + n - 1;
		register int32_t val = *ptr;

PRAGMA_UNROLL_N(8)
		while (ptr < end) {
			register const int32_t next_val = *(ptr + 1);

			if (UNLIKELY(val > next_val))
				goto fail;

			ptr++;
			val = next_val;
		}
	}
	return true;

fail:
	pr_fail("%s: forward sort error detected, incorrect ordering found\n",
		args->name);
	*rc = EXIT_FAILURE;
	return false;
}

static inline bool OPTIMIZE3 stress_qsort_verify_reverse(
	stress_args_t *args,
	const int32_t *data,
	const size_t n,
	CLOBBERED int *rc)
{
	if (g_opt_flags & OPT_FLAGS_VERIFY) {
		register const int32_t *ptr = data;
		register const int32_t *end = data + n - 1;
		register int32_t val = *ptr;

PRAGMA_UNROLL_N(8)
		while (ptr < end) {
			register int32_t next_val = *(ptr + 1);

			if (UNLIKELY(val < next_val))
				goto fail;

			ptr++;
			val = next_val;
		}
	}
	return true;

fail:
	pr_fail("%s: reverse sort error detected, incorrect ordering found\n",
		args->name);
	*rc = EXIT_FAILURE;
	return false;
}

/*
 *  stress_qsort()
 *	stress qsort
 */
static int OPTIMIZE3 stress_qsort(stress_args_t *args)
{
	uint64_t qsort_size = DEFAULT_QSORT_SIZE;
	int32_t *data;
	size_t n;
	size_t data_size;
	size_t qsort_method = 0;
	double rate;
	CLOBBERED double duration = 0.0;
	CLOBBERED double count = 0.0;
	CLOBBERED double sorted = 0.0;
	CLOBBERED int rc = EXIT_SUCCESS;
	qsort_func_t qsort_func;
#if defined(HAVE_SIGLONGJMP)
	struct sigaction old_action;
	int ret;
#endif

	stress_signal_catch_sigill();

	(void)stress_setting_get("qsort-method", &qsort_method);
	if (!stress_setting_get("qsort-size", &qsort_size)) {
		if (g_opt_flags & OPT_FLAGS_MAXIMIZE)
			qsort_size = MAX_QSORT_SIZE;
		if (g_opt_flags & OPT_FLAGS_MINIMIZE)
			qsort_size = MIN_QSORT_SIZE;
	}
	n = (size_t)qsort_size;
	data_size = n * sizeof(*data);
	data = (int32_t *)stress_mmap_populate(NULL, data_size,
			PROT_READ | PROT_WRITE,
			MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
	if (data == MAP_FAILED) {
		pr_inf_skip("%s: mmap failed allocating %zu 32 bit integers%s, errno=%d (%s), "
			"skipping stressor\n", args->name, n,
			stress_memory_free_get(),
			errno, strerror(errno));
		return EXIT_NO_RESOURCE;
	}
	(void)stress_madvise_collapse(data, data_size);
	stress_memory_anon_name_set(data, data_size, "qsort-data");

#if defined(HAVE_SIGLONGJMP)
	ret = sigsetjmp(jmp_env, 1);
	if (ret) {
		/*
		 * We return here if SIGALRM jmp'd back
		 */
		(void)stress_signal_restore(args->name, SIGALRM, &old_action);
		goto tidy;
	}
	if (stress_signal_handler(args->name, SIGALRM, stress_qsort_handler, &old_action) < 0) {
		(void)munmap((void *)data, data_size);
		return EXIT_FAILURE;
	}
#endif

	stress_sort_data_int32_init(data, n);

	qsort_func = stress_qsort_methods[qsort_method].qsort_func;
	if (stress_instance_zero(args))
		pr_inf("%s: using method '%s'\n",
			args->name, stress_qsort_methods[qsort_method].name);

	stress_proc_state_set(args->name, STRESS_STATE_SYNC_WAIT);
	stress_sync_start_wait(args);
	stress_proc_state_set(args->name, STRESS_STATE_RUN);

	do {
		double t;

		stress_sort_data_int32_shuffle(data, n);

		stress_sort_compare_reset();
		t = stress_time_now();
		/* Sort "random" data */
		qsort_func((void *)data, n, sizeof(*data), stress_sort_cmp_fwd_int32);
		duration += stress_time_now() - t;
		count += (double)stress_sort_compare_get();
		sorted += (double)n;

		if (!stress_qsort_verify_forward(args, data, n, &rc))
			break;

		if (UNLIKELY(!stress_continue_flag()))
			break;

		/* Reverse sort */
		stress_sort_compare_reset();
		t = stress_time_now();
		qsort_func((void *)data, n, sizeof(*data), stress_sort_cmp_rev_int32);
		duration += stress_time_now() - t;
		count += (double)stress_sort_compare_get();
		sorted += (double)n;

		if (!stress_qsort_verify_reverse(args, data, n, &rc))
			break;

		if (UNLIKELY(!stress_continue_flag()))
			break;

		stress_sort_data_int32_mangle(data, n);
		stress_sort_compare_reset();
		t = stress_time_now();
		qsort_func((void *)data, n, sizeof(uint32_t), stress_sort_cmp_fwd_int32);
		duration += stress_time_now() - t;
		count += (double)stress_sort_compare_get();
		sorted += (double)n;

		/* Reverse sort */
		stress_sort_compare_reset();
		t = stress_time_now();
		qsort_func((void *)data, n, sizeof(*data), stress_sort_cmp_rev_int32);
		duration += stress_time_now() - t;
		count += (double)stress_sort_compare_get();
		sorted += (double)n;

		if (!stress_qsort_verify_reverse(args, data, n, &rc))
			break;

		stress_bogo_inc(args);
	} while (stress_continue(args));

#if defined(HAVE_SIGLONGJMP)
	do_jmp = false;
	(void)stress_signal_restore(args->name, SIGALRM, &old_action);
tidy:
#endif
	stress_proc_state_set(args->name, STRESS_STATE_DEINIT);
	rate = (duration > 0.0) ? count / duration : 0.0;
	stress_metrics_set(args, "qsort comparisons per sec",
		rate, STRESS_METRIC_HARMONIC_MEAN);
	rate = (sorted > 0.0) ? count / sorted : 0.0;
	stress_metrics_set(args, "qsort comparisons per item",
		rate, STRESS_METRIC_HARMONIC_MEAN);

	pr_dbg("%s: %.2f qsort comparisons per sec\n", args->name, rate);

	(void)munmap((void *)data, data_size);

	return rc;
}

static const char *stress_qsort_method(const size_t i)
{
	return (i < SIZEOF_ARRAY(stress_qsort_methods)) ? stress_qsort_methods[i].name : NULL;
}

static const stress_opt_t opts[] = {
	{ OPT_qsort_size,   "qsort-size",   TYPE_ID_UINT64, MIN_QSORT_SIZE, MAX_QSORT_SIZE, NULL },
	{ OPT_qsort_method, "qsort-method", TYPE_ID_SIZE_T_METHOD, 0, 0, stress_qsort_method },
	END_OPT,
};

static const stress_exercises_t exercises[] = {
	STRESS_EX_FEATURE("d-cache"),
	STRESS_EX_FEATURE("d-tlb-write-miss"),
	STRESS_EX_FEATURE("hot-package"),
	STRESS_EX_FEATURE("memory-cmp"),
	STRESS_EX_FEATURE("power-core"),
	STRESS_EX_FEATURE("speculation-mispredict"),
	STRESS_EX_FEATURE("user-time"),

	STRESS_EX_END,
};

const stressor_info_t stress_qsort_info = {
	.stressor = stress_qsort,
	.classifier = CLASS_CPU_CACHE | CLASS_CPU | CLASS_MEMORY | CLASS_SORT | CLASS_HOT,
	.opts = opts,
	.verify = VERIFY_OPTIONAL,
	.help = help,
	.exercises = exercises,
};
